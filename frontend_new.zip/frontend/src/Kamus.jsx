import axios from "axios";
import { useEffect } from "react";
import { useState } from "react";

const Kamus = () => {
  const text = "NGOKO | KRAMA MADYA | KRAMA INGGIL";
  const [displayText, setDisplayText] = useState("");
  const [index, setIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  const [kamus, setKamus] = useState([]);
  const [error, setError] = useState("");
  const [inputText, setInputText] = useState("");
  const [translatedText, setTranslatedText] = useState("");

  const [loading, setLoading] = useState(false);

  const handleTranslate = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const response = await fetch("http://localhost:5000/api/translate", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ text: inputText })
      });

      const data = await response.json();
      setTranslatedText(data.translatedText);
    } catch (error) {
      console.error("Terjadi kesalahan:", error);
    } finally {
      setLoading(false);
    }
  };


  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_BASE_URL_API}/kamus`
        );
        if (response.status !== 200) {
          throw new Error(response.data.message || "Terjadi kesalahan");
        }

        setKamus(response.data.data);
      } catch (error) {
        if (error.response) {
          setError(
            error.response.data.message || "Terjadi kesalahan pada server"
          );
        } else if (error.request) {
          setError("Tidak dapat terhubung ke server");
        } else {
          setError(error.message);
        }
      }
    };
    fetchData();
  }, []);

  useEffect(() => {
    const timeout = setTimeout(() => {
      if (!isDeleting && index < text.length) {
        setDisplayText(text.slice(0, index + 1));
        setIndex(index + 1);
      } else if (isDeleting && index > 0) {
        setDisplayText(text.slice(0, index - 1));
        setIndex(index - 1);
      } else if (index === text.length) {
        setTimeout(() => setIsDeleting(true), 1000);
      } else if (index === 0 && isDeleting) {
        setIsDeleting(false);
      }
    }, 100);

    return () => clearTimeout(timeout);
  }, [index, isDeleting]);

  return (
    <>
      <section id="kamus">
        <div className="col-kamus">
          <div className="header-kamus">
            <div className="left-header-kamus">
              <div className="title-header-kamus">
                PENERJEMAH UNTUK 100+ BAHASA JAWA
              </div>
              <div className="desc-header-kamus">
                "Penerjemah untuk 100+ Bahasa Jawa" adalah alat terjemahan
                canggih yang dapat menerjemahkan lebih dari 100 bahasa ke dalam
                Bahasa Jawa dan sebaliknya."
              </div>
              <div className="text-bahasa">{displayText}|</div>
              <div className="col-btn-kamus">
                <a href="#col-card-kamus">
                  {" "}
                  <button className="btn-kamus">Lihat Kamus Sekarang</button>
                </a>
                <div className="line-kamus"></div>
              </div>
            </div>
            <div className="right-header-kamus">
              <img
                src="assets/img-penerjemah.png"
                style={{ marginTop: "-10px" }}
                width={450}
                alt=""
              />
            </div>
          </div>

          <div className="title-header-kamus">
                Translator Bahasa Indonesia ke Bahasa Jawa
              </div>

          <div class="flex">
            <form onSubmit={handleTranslate} class="w-1/4">
              <span class="text-sm font-medium text-gray-700"> Masukkan Teks </span>

              <div
                class="relative mt-0.5 overflow-hidden rounded border border-gray-300 shadow-sm focus-within:ring focus-within:ring-blue-600"
              >
                <textarea
                  id="Notes"
                  class="w-full h-full resize-none border-none focus-within:ring-0 sm:text-sm"
                  rows="4"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  placeholder="Masukkan teks"
                  required
                ></textarea>

                <div class="flex items-center justify-end gap-2 p-1.5">
                  <button
                    type="submit"
                    class="rounded border border-gray-300 px-3 py-1.5 text-sm font-medium text-gray-900 shadow-sm transition-colors hover:bg-gray-100"
                  >
                    Translate
                  </button>
                </div>
              </div>
            </form>

            <div class="px-5">
              
              <p class="text-sm font-medium text-gray-700">Hasil :</p>
            {loading ? (
              <p><em>Menerjemahkan...</em></p>
            ) : translatedText && (
              <p>{translatedText}</p>
            )}
            </div>
          </div>


          <div id="col-card-kamus"></div>
          <div className="col-card-kamus">
            {kamus.length === 0 ? (
              <p>{error}</p>
            ) : (
              kamus.map((data, index) => (
                <div className="card-kamus" key={index}>
                  <div className="box-number">{index + 1}</div>
                  <div className="title-card-kamus">
                    {data.bahasa_indonesia}
                  </div>
                  <div className="line-card-kampus"> </div>
                  <div className="text-ngoko">Ngoko : {data.ngoko}</div>
                  <div className="text-madya">
                    Krama Madya : {data.krama_madya}
                  </div>
                  <div className="text-inggil">
                    Krama Inggil : {data.krama_inggil}
                  </div>
                </div>
              ))
            )}

            {/* <div className="card-kamus">
              <div className="box-number">2</div>
              <div className="title-card-kamus">Kamu</div>
              <div className="line-card-kampus"> </div>
              <div className="text-ngoko">Ngoko : Kowe</div>
              <div className="text-madya">Krama Madya : Panjenengan</div>
              <div className="text-inggil">Krama Inggil : Sampeyan</div>
            </div>

            <div className="card-kamus">
              <div className="box-number">3</div>
              <div className="title-card-kamus">Makan</div>
              <div className="line-card-kampus"> </div>
              <div className="text-ngoko">Ngoko : Mangan</div>
              <div className="text-madya">Krama Madya : Nedha</div>
              <div className="text-inggil">Krama Inggil : Dhahar</div>
            </div>

            <div className="card-kamus">
              <div className="box-number">4</div>
              <div className="title-card-kamus">Minum</div>
              <div className="line-card-kampus"> </div>
              <div className="text-ngoko">Ngoko : Ngombe</div>
              <div className="text-madya">Krama Madya : Ngunjuk</div>
              <div className="text-inggil">Krama Inggil : Ngunjuk</div>
            </div>

            <div className="card-kamus">
              <div className="box-number">5</div>
              <div className="title-card-kamus">Tidur</div>
              <div className="line-card-kampus"> </div>
              <div className="text-ngoko">Ngoko : Turu</div>
              <div className="text-madya">Krama Madya : Sare</div>
              <div className="text-inggil">Krama Inggil : Tilem</div>
            </div>

            <div className="card-kamus">
              <div className="box-number">6</div>
              <div className="title-card-kamus">Rumah</div>
              <div className="line-card-kampus"> </div>
              <div className="text-ngoko">Ngoko : Omah</div>
              <div className="text-madya">Krama Madya : Griya</div>
              <div className="text-inggil">Krama Inggil : Dalem</div>
            </div>
            <div className="card-kamus">
              <div className="box-number">7</div>
              <div className="title-card-kamus">Melihat</div>
              <div className="line-card-kampus"> </div>
              <div className="text-ngoko">Ngoko : Ndelok</div>
              <div className="text-madya">Krama Madya : Nonton</div>
              <div className="text-inggil">Krama Inggil : Mriksani</div>
            </div>
            <div className="card-kamus">
              <div className="box-number">8</div>
              <div className="title-card-kamus">Anak</div>
              <div className="line-card-kampus"> </div>
              <div className="text-ngoko">Ngoko : Bocah</div>
              <div className="text-madya">Krama Madya : Putra</div>
              <div className="text-inggil">Krama Inggil : Putra Dalem</div>
            </div> */}
          </div>
        </div>
      </section>
    </>
  );
};
export default Kamus;
