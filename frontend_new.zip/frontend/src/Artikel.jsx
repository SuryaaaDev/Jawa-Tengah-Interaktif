import axios from "axios";
import { useEffect, useState } from "react";

const Artikel = () => {
  const [artikel, setArtikel] = useState([]);
  const [error, setError] = useState("");
  const [latestArtikel, setLatestArtikel] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const latestCount = 5;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_BASE_URL_API}/artikel`
        );
        if (response.status !== 200) {
          throw new Error(response.data.message || "Terjadi kesalahan");
        }
        setArtikel(response.data.data);

        const latestResponse = await axios.get(
          `${import.meta.env.VITE_BASE_URL_API}/artikel?latest=${latestCount}`
        );
        if (latestResponse.status !== 200) {
          throw new Error(latestResponse.data.message || "Terjadi kesalahan");
        }
        setLatestArtikel(latestResponse.data.data);
      } catch (err) {
        if (err.response) {
          setError(
            err.response.data.message || "Terjadi kesalahan pada server"
          );
        } else if (err.request) {
          setError("Tidak dapat terhubung ke server");
        } else {
          setError(err.message);
        }
      }
    };

    fetchData();
  }, []);

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const filteredArtikel = artikel.filter(
    (data) =>
      data.judul.toLowerCase().includes(searchTerm.toLowerCase()) ||
      data.deskripsi.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <>
      <section id="artikel">
        <div className="col-artikel">
          <div className="header-artikel">
            <div className="col-text-header-artikel">
              <div className="text-jawa">JAWA</div>
              <div className="text-tengah-interaktif">TENGAH INTERAKTIF</div>
              <div className="text-desc-jawa">
                Jawa Tengah Interaktif adalah konsep digital yang menggabungkan
                teknologi dengan kekayaan budaya, alam, dan sejarah provinsi
                Jawa Tengah
              </div>
              <div className="col-searching-jawa">
                <div className="box-icon-search">
                  <i class="bx bx-search"></i>
                </div>
                <input
                  type="text"
                  className="input-jawa"
                  placeholder="Search"
                  value={searchTerm}
                  onChange={handleSearch}
                />
              </div>
            </div>
          </div>
          <div className="parent-berita-artikel" style={{ marginTop: "20px" }}>
            <div className="column-berita-artikel">
              {artikel.length === 0 ? (
                <p>{error}</p>
              ) : (
                filteredArtikel.map((data, index) => (
                  <div className="card-berita" key={index}>
                    <img
                      className="header-card"
                      src={data.url_gambar}
                      alt={data.judul}
                    />
                    <div className="content-card">
                      <div className="title-card">{data.judul}</div>
                      <div className="desc-card">{data.deskripsi}</div>
                    </div>
                    <div className="footer-card">
                      <div className="left-footer-card">
                        <div className="penerbit">{data.author}</div>
                        <div className="tanggal-terbit">
                          {data.tanggal_artikel}
                        </div>
                      </div>
                      <div className="right-footer-card">
                        <a href={`/detail-artikel/${data.id}`}>
                          <button className="btn-kunjungi">
                            <span>Lihat Detail</span>
                          </button>
                        </a>
                      </div>
                    </div>
                  </div>
                ))
              )}
              {/* <div className="card-berita">
                <img className="header-card" src="assets/artikel1.jpg"></img>
                <div className="content-card">
                  <div className="title-card">
                    Wayang, Warisan Budaya Jawa yang Mendunia
                  </div>
                  <div className="desc-card">
                    Wayang merupakan seni pertunjukan khas Jawa yang telah
                    diakui sebagai Warisan Budaya Tak Benda oleh UNESCO.
                  </div>
                </div>
                <div className="footer-card">
                  <div className="left-footer-card">
                    <div className="penerbit">Bintang Agustiano Effendy</div>
                    <div className="tanggal-terbit">11 Agustus 2007</div>
                  </div>
                  <div className="right-footer-card">
                    <a href="/detail-artikel">
                      <button className="btn-kunjungi">
                        {" "}
                        <span>Lihat Detail</span>
                      </button>
                    </a>
                  </div>
                </div>
              </div>
              <div className="card-berita">
                <img className="header-card" src="assets/artikel2.jpg"></img>
                <div className="content-card">
                  <div className="title-card">
                    Wayang, Warisan Budaya Jawa yang Mendunia
                  </div>
                  <div className="desc-card">
                    Wayang merupakan seni pertunjukan khas Jawa yang telah
                    diakui sebagai Warisan Budaya Tak Benda oleh UNESCO.
                  </div>
                </div>
                <div className="footer-card">
                  <div className="left-footer-card">
                    <div className="penerbit">Bintang Agustiano Effendy</div>
                    <div className="tanggal-terbit">11 Agustus 2007</div>
                  </div>
                  <div className="right-footer-card">
                    <a href="/detail-artikel">
                      <button className="btn-kunjungi">
                        {" "}
                        <span>Lihat Detail</span>
                      </button>
                    </a>
                  </div>
                </div>
              </div>
              <div className="card-berita">
                <img className="header-card" src="assets/artikel1.jpg"></img>
                <div className="content-card">
                  <div className="title-card">
                    Wayang, Warisan Budaya Jawa yang Mendunia
                  </div>
                  <div className="desc-card">
                    Wayang merupakan seni pertunjukan khas Jawa yang telah
                    diakui sebagai Warisan Budaya Tak Benda oleh UNESCO.
                  </div>
                </div>
                <div className="footer-card">
                  <div className="left-footer-card">
                    <div className="penerbit">Bintang Agustiano Effendy</div>
                    <div className="tanggal-terbit">11 Agustus 2007</div>
                  </div>
                  <div className="right-footer-card">
                    <a href="/detail-artikel">
                      <button className="btn-kunjungi">
                        {" "}
                        <span>Lihat Detail</span>
                      </button>
                    </a>
                  </div>
                </div>
              </div>
              <div className="card-berita">
                <img className="header-card" src="assets/artikel2.jpg"></img>
                <div className="content-card">
                  <div className="title-card">
                    Wayang, Warisan Budaya Jawa yang Mendunia
                  </div>
                  <div className="desc-card">
                    Wayang merupakan seni pertunjukan khas Jawa yang telah
                    diakui sebagai Warisan Budaya Tak Benda oleh UNESCO.
                  </div>
                </div>
                <div className="footer-card">
                  <div className="left-footer-card">
                    <div className="penerbit">Bintang Agustiano Effendy</div>
                    <div className="tanggal-terbit">11 Agustus 2007</div>
                  </div>
                  <div className="right-footer-card">
                    <a href="/detail-artikel">
                      <button className="btn-kunjungi">
                        {" "}
                        <span>Lihat Detail</span>
                      </button>
                    </a>
                  </div>
                </div>
              </div>
              <div className="card-berita">
                <img className="header-card" src="assets/artikel1.jpg"></img>
                <div className="content-card">
                  <div className="title-card">
                    Wayang, Warisan Budaya Jawa yang Mendunia
                  </div>
                  <div className="desc-card">
                    Wayang merupakan seni pertunjukan khas Jawa yang telah
                    diakui sebagai Warisan Budaya Tak Benda oleh UNESCO.
                  </div>
                </div>
                <div className="footer-card">
                  <div className="left-footer-card">
                    <div className="penerbit">Bintang Agustiano Effendy</div>
                    <div className="tanggal-terbit">11 Agustus 2007</div>
                  </div>
                  <div className="right-footer-card">
                    <a href="/detail-artikel">
                      <button className="btn-kunjungi">
                        {" "}
                        <span>Lihat Detail</span>
                      </button>
                    </a>
                  </div>
                </div>
              </div>
              <div className="card-berita">
                <img className="header-card" src="assets/artikel2.jpg"></img>
                <div className="content-card">
                  <div className="title-card">
                    Wayang, Warisan Budaya Jawa yang Mendunia
                  </div>
                  <div className="desc-card">
                    Wayang merupakan seni pertunjukan khas Jawa yang telah
                    diakui sebagai Warisan Budaya Tak Benda oleh UNESCO.
                  </div>
                </div>
                <div className="footer-card">
                  <div className="left-footer-card">
                    <div className="penerbit">Bintang Agustiano Effendy</div>
                    <div className="tanggal-terbit">11 Agustus 2007</div>
                  </div>
                  <div className="right-footer-card">
                    <a href="/detail-artikel">
                      <button className="btn-kunjungi">
                        {" "}
                        <span>Lihat Detail</span>
                      </button>
                    </a>
                  </div>
                </div>
              </div> */}
            </div>
            <div className="column-berita-terbaru">
              <div className="title-berita-terbaru">Berita terbaru</div>
              <div className="col-line">
                <div className="line"></div>
              </div>
              <div className="col-artikel-baru">
                {latestArtikel.length === 0 ? (
                  <p>{error}</p>
                ) : (
                  latestArtikel.map((data, index) => (
                    <a
                      href={`/detail-artikel/${data.id}`}
                      className="card-berita-terbaru"
                      key={index}
                    >
                      <div className="left-berita">
                        <img src={data.url_gambar} alt="" />
                      </div>
                      <div className="right-berita">
                        <div className="title-berita-baru">{data.judul}</div>
                        <div className="desc-berita-baru">
                          {data.deskripsi.length > 45
                            ? data.deskripsi.substring(0, 45) + "..."
                            : data.deskripsi}
                        </div>
                      </div>
                    </a>
                  ))
                )}
                {/* <a href="/detail-artikel" className="card-berita-terbaru">
                  <div className="left-berita">
                    <img src="assets/artikel2.jpg" alt="" />
                  </div>
                  <div className="right-berita">
                    <div className="title-berita-baru">
                      Masyarakat Purwekerto bagi bagi takjil
                    </div>
                    <div className="desc-berita-baru">
                      Masyarakat Purwekerto bagi bagi takjil selama bulan
                      ramadhan
                    </div>
                  </div>
                </a>
                <a href="/detail-artikel" className="card-berita-terbaru">
                  <div className="left-berita">
                    <img src="assets/artikel2.jpg" alt="" />
                  </div>
                  <div className="right-berita">
                    <div className="title-berita-baru">
                      Masyarakat Purwekerto bagi bagi takjil
                    </div>
                    <div className="desc-berita-baru">
                      Masyarakat Purwekerto bagi bagi takjil selama bulan
                      ramadhan
                    </div>
                  </div>
                </a>
                <a href="/detail-artikel" className="card-berita-terbaru">
                  <div className="left-berita">
                    <img src="assets/artikel2.jpg" alt="" />
                  </div>
                  <div className="right-berita">
                    <div className="title-berita-baru">
                      Masyarakat Purwekerto bagi bagi takjil
                    </div>
                    <div className="desc-berita-baru">
                      Masyarakat Purwekerto bagi bagi takjil selama bulan
                      ramadhan
                    </div>
                  </div>
                </a>
                <a href="/detail-artikel" className="card-berita-terbaru">
                  <div className="left-berita">
                    <img src="assets/artikel2.jpg" alt="" />
                  </div>
                  <div className="right-berita">
                    <div className="title-berita-baru">
                      Masyarakat Purwekerto bagi bagi takjil
                    </div>
                    <div className="desc-berita-baru">
                      Masyarakat Purwekerto bagi bagi takjil selama bulan
                      ramadhan
                    </div>
                  </div>
                </a>
                <a href="/detail-artikel" className="card-berita-terbaru">
                  <div className="left-berita">
                    <img src="assets/artikel2.jpg" alt="" />
                  </div>
                  <div className="right-berita">
                    <div className="title-berita-baru">
                      Masyarakat Purwekerto bagi bagi takjil
                    </div>
                    <div className="desc-berita-baru">
                      Masyarakat Purwekerto bagi bagi takjil selama bulan
                      ramadhan
                    </div>
                  </div>
                </a> */}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
export default Artikel;
