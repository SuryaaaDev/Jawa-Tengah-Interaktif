import axios from "axios";
import { useEffect, useState } from "react";

const Tradisi = () => {
  const [tradisi, setTradisi] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_BASE_URL_API}/tradisi`
        );
        if (response.status !== 200) {
          throw new Error(response.data.message || "Terjadi kesalahan");
        }
        setTradisi(response.data.data);
      } catch (err) {
        if (err.response) {
          setError(
            err.response.data.message || "Terjadi kesalahan pada server"
          );
        } else if (err.request) {
          setError("Tidak dapat terhubung ke server");
        } else {
          setError(err.message);
        }
      }
    };
    fetchData();
  }, []);
  console.log(tradisi);
  return (
    <>
      <section id="kamus">
        <div className="col-kamus">
          <div className="header-kamus">
            <div className="left-header-kamus">
              <div className="title-header-kamus">
                WARISAN BUDAYA & TRADISI NUSANTARA
              </div>
              <div className="desc-header-kamus">
                "Setiap daerah di Indonesia memiliki tradisi unik yang kaya akan
                makna dan filosofi. Dari upacara adat hingga seni pertunjukan"
              </div>
              <div className="text-bahasa">
                Ayo lihat warisan budaya dan tradisi nusantara dari berbagai
                daerah{" "}
              </div>
              <div className="col-btn-kamus">
                <a href="#col-card-tradisi">
                  {" "}
                  <button className="btn-kamus">Lihat Tradisi Sekarang</button>
                </a>
                <div className="line-kamus"></div>
              </div>
            </div>
            <div className="right-header-kamus">
              <img src="assets/img-tradisi.png" width={510} alt="" />
            </div>
          </div>
          <div className="col-card-tradisi" id="col-card-tradisi">
            {tradisi.length === 0 ? (
              <p>error</p>
            ) : (
              tradisi.map((data, index) => (
                <div className="card-tradisi" key={index}>
                  <img src={data.url_gambar} width={100} alt="" />
                  <div className="content-card-tradisi">
                    <div className="title-card-tradisi">{data.judul}</div>
                    <div className="desc-card-tradisi">
                      {data.konten.length > 65
                        ? data.konten.substring(0, 65) + "..."
                        : data.konten}
                    </div>
                    <a href={`/tradisi-detail/${data.id}`}>
                      <button className="btn-card-tradisi">Lihat Detail</button>
                    </a>
                  </div>
                </div>
              ))
            )}
            {/* 
            <div className="card-tradisi">
              <img src="assets/tradisi1.jpg" width={100} alt="" />
              <div className="content-card-tradisi">
                <div className="title-card-tradisi">
                  Tradisi Solo : Warisan Budaya yang Tak Lekang oleh Waktu
                </div>
                <div className="desc-card-tradisi">
                  Solo merupakan salah satu daerah di Jawa Barat yang kaya akan
                  tradisi...
                </div>
                <a href="/tradisi-detail">
                  {" "}
                  <button className="btn-card-tradisi">Lihat Detail</button>
                </a>
              </div>
            </div>
            <div className="card-tradisi">
              <img src="assets/tradisi1.jpg" width={100} alt="" />
              <div className="content-card-tradisi">
                <div className="title-card-tradisi">
                  Tradisi Solo : Warisan Budaya yang Tak Lekang oleh Waktu
                </div>
                <div className="desc-card-tradisi">
                  Solo merupakan salah satu daerah di Jawa Barat yang kaya akan
                  tradisi...
                </div>
                <a href="/tradisi-detail">
                  {" "}
                  <button className="btn-card-tradisi">Lihat Detail</button>
                </a>
              </div>
            </div>
            <div className="card-tradisi">
              <img src="assets/tradisi1.jpg" width={100} alt="" />
              <div className="content-card-tradisi">
                <div className="title-card-tradisi">
                  Tradisi Solo : Warisan Budaya yang Tak Lekang oleh Waktu
                </div>
                <div className="desc-card-tradisi">
                  Solo merupakan salah satu daerah di Jawa Barat yang kaya akan
                  tradisi...
                </div>
                <a href="/tradisi-detail">
                  {" "}
                  <button className="btn-card-tradisi">Lihat Detail</button>
                </a>
              </div>
            </div>
            <div className="card-tradisi">
              <img src="assets/tradisi1.jpg" width={100} alt="" />
              <div className="content-card-tradisi">
                <div className="title-card-tradisi">
                  Tradisi Solo : Warisan Budaya yang Tak Lekang oleh Waktu
                </div>
                <div className="desc-card-tradisi">
                  Solo merupakan salah satu daerah di Jawa Barat yang kaya akan
                  tradisi...
                </div>
                <a href="/tradisi-detail">
                  {" "}
                  <button className="btn-card-tradisi">Lihat Detail</button>
                </a>
              </div>
            </div>
            <div className="card-tradisi">
              <img src="assets/tradisi1.jpg" width={100} alt="" />
              <div className="content-card-tradisi">
                <div className="title-card-tradisi">
                  Tradisi Solo : Warisan Budaya yang Tak Lekang oleh Waktu
                </div>
                <div className="desc-card-tradisi">
                  Solo merupakan salah satu daerah di Jawa Barat yang kaya akan
                  tradisi...
                </div>
                <a href="/tradisi-detail">
                  {" "}
                  <button className="btn-card-tradisi">Lihat Detail</button>
                </a>
              </div>
            </div>
            <div className="card-tradisi">
              <img src="assets/tradisi1.jpg" width={100} alt="" />
              <div className="content-card-tradisi">
                <div className="title-card-tradisi">
                  Tradisi Solo : Warisan Budaya yang Tak Lekang oleh Waktu
                </div>
                <div className="desc-card-tradisi">
                  Solo merupakan salah satu daerah di Jawa Barat yang kaya akan
                  tradisi...
                </div>
                <a href="/tradisi-detail">
                  {" "}
                  <button className="btn-card-tradisi">Lihat Detail</button>
                </a>
              </div>
            </div>
            <div className="card-tradisi">
              <img src="assets/tradisi1.jpg" width={100} alt="" />
              <div className="content-card-tradisi">
                <div className="title-card-tradisi">
                  Tradisi Solo : Warisan Budaya yang Tak Lekang oleh Waktu
                </div>
                <div className="desc-card-tradisi">
                  Solo merupakan salah satu daerah di Jawa Barat yang kaya akan
                  tradisi...
                </div>
                <a href="/tradisi-detail">
                  {" "}
                  <button className="btn-card-tradisi">Lihat Detail</button>
                </a>
              </div>
            </div>
            <div className="card-tradisi">
              <img src="assets/tradisi1.jpg" width={100} alt="" />
              <div className="content-card-tradisi">
                <div className="title-card-tradisi">
                  Tradisi Solo : Warisan Budaya yang Tak Lekang oleh Waktu
                </div>
                <div className="desc-card-tradisi">
                  Solo merupakan salah satu daerah di Jawa Barat yang kaya akan
                  tradisi...
                </div>
                <a href="/tradisi-detail">
                  {" "}
                  <button className="btn-card-tradisi">Lihat Detail</button>
                </a>
              </div>
            </div>
            <div className="card-tradisi">
              <img src="assets/tradisi1.jpg" width={100} alt="" />
              <div className="content-card-tradisi">
                <div className="title-card-tradisi">
                  Tradisi Solo : Warisan Budaya yang Tak Lekang oleh Waktu
                </div>
                <div className="desc-card-tradisi">
                  Solo merupakan salah satu daerah di Jawa Barat yang kaya akan
                  tradisi...
                </div>
                <a href="/tradisi-detail">
                  {" "}
                  <button className="btn-card-tradisi">Lihat Detail</button>
                </a>
              </div>
            </div> */}
          </div>
        </div>
      </section>
    </>
  );
};
export default Tradisi;
