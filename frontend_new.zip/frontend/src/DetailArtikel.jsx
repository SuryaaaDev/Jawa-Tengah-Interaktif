import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const DetailArtikel = () => {
  const [artikel, setArtikel] = useState([]);
  const [artikelLainnya, setArtikelLainnya] = useState([]);
  const [error, setError] = useState("");
  const { id } = useParams();

  useEffect(() => {
    const fetchArtikel = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_BASE_URL_API}/artikel/${id}`
        );
        if (response.status !== 200) {
          throw new Error("Artikel tidak ditemukan");
        }
        setArtikel(response.data.data);

        const fetchAllData = await axios.get(
          `${import.meta.env.VITE_BASE_URL_API}/artikel`
        );

        const semuaArtikel = fetchAllData.response.data.data;

        const filteredArtikel = semuaArtikel.filter(
          (item) => item.id !== parseInt(id)
        );
        setArtikelLainnya(filteredArtikel);
      } catch (err) {
        setError(err.message);
      }
    };

    fetchArtikel();
  }, [id]);

  return (
    <>
      <section id="detailArtikel">
        <div className="content-detail-artikel">
          <div className="left-detail-artikel">
            {error ? <p>{error}</p> : ""}
            <img src={artikel.url_gambar} alt="" />
            <div className="col-title-detail-artikel">
              <div className="title-detail-artikel">{artikel.judul}</div>
              <div className="penerbit-detail-artikel">
                Penulis : {artikel.author}
              </div>
            </div>
            {artikel.konten}
            <a href="/" style={{ width: "100%" }}>
              {" "}
              <button className="btn-back" style={{ width: "100%" }}>
                Kembali
              </button>
            </a>
          </div>

          <div className="right-detail-artikel">
            <div className="title-berita-lainnya-detail">Berita lainnya</div>
            <div className="col-line-detail">
              <div className="line-detail"></div>
            </div>
            <div className="parent-col-berita-lainnya">
              {artikelLainnya.length === 0 ? (
                <p>Tidak ada data artikel lainnya</p>
              ) : (
                <div className="col-berita-lainnya-detail">
                  <div className="left-berita-detail">
                    <img src={artikelLainnya.url_gambar} width={200} alt="" />
                  </div>
                  <div className="right-berita-detail">
                    <div className="title-berita-detail">
                      {artikelLainnya.judul}
                    </div>
                    <div className="desc-berita-detail">
                      {artikelLainnya.deskripsi}
                    </div>
                    <a href={`/detail-artikel/${artikelLainnya.id}`}>
                      <button className="btn-back-berita-lainnya-detail">
                        Lihat Detail
                      </button>
                    </a>
                  </div>
                </div>
              )}
              {/* <div className="col-berita-lainnya-detail">
                <div className="left-berita-detail">
                  <img src={artikelLainnya.url_gambar} width={200} alt="" />
                </div>
                <div className="right-berita-detail">
                  <div className="title-berita-detail">
                    Masyarakat Purwekerto bagi bagi takjil
                  </div>
                  <div className="desc-berita-detail">
                    Masyarakat Purwekerto bagi bagi takjil selama bulan ramadhan
                  </div>
                  <button className="btn-back-berita-lainnya-detail">
                    Lihat Detail
                  </button>
                </div>
              </div>
              <div className="col-berita-lainnya-detail">
                <div className="left-berita-detail">
                  <img src="assets/artikel2.jpg" width={200} alt="" />
                </div>
                <div className="right-berita-detail">
                  <div className="title-berita-detail">
                    Masyarakat Purwekerto bagi bagi takjil
                  </div>
                  <div className="desc-berita-detail">
                    Masyarakat Purwekerto bagi bagi takjil selama bulan ramadhan
                  </div>
                  <button className="btn-back-berita-lainnya-detail">
                    Lihat Detail
                  </button>
                </div>
              </div>
              <div className="col-berita-lainnya-detail">
                <div className="left-berita-detail">
                  <img src="assets/artikel2.jpg" width={200} alt="" />
                </div>
                <div className="right-berita-detail">
                  <div className="title-berita-detail">
                    Masyarakat Purwekerto bagi bagi takjil
                  </div>
                  <div className="desc-berita-detail">
                    Masyarakat Purwekerto bagi bagi takjil selama bulan ramadhan
                  </div>
                  <button className="btn-back-berita-lainnya-detail">
                    Lihat Detail
                  </button>
                </div>
              </div>
              <div className="col-berita-lainnya-detail">
                <div className="left-berita-detail">
                  <img src="assets/artikel2.jpg" width={200} alt="" />
                </div>
                <div className="right-berita-detail">
                  <div className="title-berita-detail">
                    Masyarakat Purwekerto bagi bagi takjil
                  </div>
                  <div className="desc-berita-detail">
                    Masyarakat Purwekerto bagi bagi takjil selama bulan ramadhan
                  </div>
                  <button className="btn-back-berita-lainnya-detail">
                    Lihat Detail
                  </button>
                </div>
              </div> */}
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
export default DetailArtikel;
