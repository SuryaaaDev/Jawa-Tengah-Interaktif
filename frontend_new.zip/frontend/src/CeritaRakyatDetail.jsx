import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const CeritaRakyatDetail = () => {
  const [data, setData] = useState([]);
  const [ceritaLainnya, setCeritaLainnya] = useState([]);
  const [error, setError] = useState("");
  const { id } = useParams();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_BASE_URL_API}/cerita/${id}`
        );
        if (response.status !== 200) {
          throw new Error("Data tidak ditemukan");
        }
        setData(response.data.data);

        const fetchAllData = await axios.get(
          `${import.meta.env.VITE_BASE_URL_API}/cerita`
        );

        const semuaCerita = fetchAllData.data.data;

        const filteredCerita = semuaCerita.filter(
          (item) => item.id !== parseInt(id)
        );

        setCeritaLainnya(filteredCerita);
      } catch (err) {
        setError(err.message);
      }
    };
    fetchData();
  }, [id]);
  console.log(ceritaLainnya);
  return (
    <>
      <section className="cerita-rakyat-detail">
        <div className="col-cerita-rakyat-detail">
          <a href="/cerita-rakyat">
            <div
              className="col-kembali"
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                cursor: "pointer",
              }}
            >
              <i class="bx bx-left-arrow-alt"></i> Kembali
            </div>
          </a>
          <div className="header-cerita-rakyat-detail">
            <div className="left-cerita-rakyat-detail">
              <img
                src={data.url_gambar}
                style={{ borderRadius: "5px" }}
                width={400}
                alt=""
              />
            </div>
            <div className="right-cerita-rakyat-detail">
              <div className="title-cerita-rakyat-detail">{data.judul}</div>
              <div className="col-desc-cerita-rakyat-detail">
                <div className="desc-cerita-rakyat-detail">{data.deskripsi}</div>
              </div>
              <audio className="audio" controls>
                <source src={data.url_audio} type="audio/mpeg" />
              </audio>
            </div>
          </div>
          <div className="footer-cerita-rakyat-detail">
            <div className="text-dongeng-lainnya-detail">Dongeng Lainnya</div>
            <div className="col-dongeng-lainnya-detail">
              {ceritaLainnya.length === 0 ? (
                <p>Tidak ada dongeng lainnya</p>
              ) : (
                ceritaLainnya.map((data, index) => (
                  <img src={data.url_gambar} width={150} alt="" key={index} />
                ))
              )}
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
export default CeritaRakyatDetail;
