import axios from "axios";
import { useEffect, useState } from "react";

const CeritaRakyat = () => {
  const [cerita, setCerita] = useState([]);
  const [error, setError] = useState("");
  const [latestCerita, setLatestCerita] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const latestCount = 5;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_BASE_URL_API}/cerita`
        );
        if (response.status !== 200) {
          throw new Error(response.data.message || "Terjadi kesalahan");
        }
        setCerita(response.data.data);

        const latestResponse = await axios.get(
          `${import.meta.env.VITE_BASE_URL_API}/cerita?latest=${latestCount}`
        );
        if (latestResponse.status !== 200) {
          throw new Error(latestResponse.data.message || "Terjadi kesalahan");
        }
        setLatestCerita(latestResponse.data.data);
      } catch (err) {
        if (err.response) {
          setError(
            err.response.data.message || "Terjadi kesalahan pada server"
          );
        } else if (err.request) {
          setError("Tidak dapat terhubung ke server");
        } else {
          setError(err.message);
        }
      }
    };

    fetchData();
  }, []);

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const filteredCerita = cerita.filter(
    (data) =>
      data.judul.toLowerCase().includes(searchTerm.toLowerCase()) ||
      data.deskripsi.toLowerCase().includes(searchTerm.toLowerCase())
  );
  return (
    <>
      <section id="artikel">
        <div className="col-artikel">
          <div className="header-artikel" id="header-cerita-rakyat">
            <div className="col-text-header-artikel">
              <div className="text-jawa">
                <img src="/assets/logo-footer.png" width={300} alt="" />
              </div>
              <div className="text-tengah-interaktif" id="text-cerita">
                CERITA RAKYAT
              </div>
              <div className="text-desc-jawa">
                Jawa Tengah Interaktif menghadirkan kisah-kisah rakyat
                legendaris dari berbagai daerah di Jawa Tengah dalam format
                digital yang menarik
              </div>
              <div className="col-searching-jawa">
                <div className="box-icon-search">
                  <i class="bx bx-search"></i>
                </div>
                <input
                  type="text"
                  className="input-jawa"
                  placeholder="Search"
                  value={searchTerm}
                  onChange={handleSearch}
                />
              </div>
            </div>
          </div>
          <div className="parent-berita-artikel" style={{ marginTop: "20px" }}>
            <div id="column-cerita-rakyat">
              {cerita.length === 0 ? (
                <p>{error}</p>
              ) : (
                filteredCerita.map((data, index) => (
                  <div className="card-cerita" key={index}>
                    <img
                      className="header-card"
                      id="header-cerita"
                      src={data.url_gambar}
                    ></img>
                    <div className="content-card">
                      <div className="title-card">{data.judul}</div>
                      <div className="desc-card">
                        {data.deskripsi.length > 70
                          ? data.deskripsi.substring(0, 70) + "..."
                          : data.deskripsi}
                      </div>
                    </div>
                    <div className="footer-card">
                      <div className="left-footer-card">
                        <div className="penerbit">{data.author}</div>
                        <div className="tanggal-terbit">
                          {data.tanggal_cerita}
                        </div>
                      </div>
                      <div className="right-footer-card">
                        <a href={`/cerita-rakyat-detail/${data.id}`}>
                          <button className="btn-kunjungi">
                            <span>Lihat Detail</span>
                          </button>
                        </a>
                      </div>
                    </div>
                  </div>
                ))
              )}
              {/* <div className="card-cerita">
                <img
                  className="header-card"
                  id="header-cerita"
                  src="assets/cerita3.jpg"
                ></img>
                <div className="content-card">
                  <div className="title-card">
                    Wayang, Warisan Budaya Jawa yang Mendunia
                  </div>
                  <div className="desc-card">
                    Wayang merupakan seni pertunjukan khas Jawa yang telah
                    diakui sebagai Warisan Budaya Tak Benda oleh UNESCO.
                  </div>
                </div>
                <div className="footer-card">
                  <div className="left-footer-card">
                    <div className="penerbit">Bintang Agustiano Effendy</div>
                    <div className="tanggal-terbit">11 Agustus 2007</div>
                  </div>
                  <div className="right-footer-card">
                    <a href="/cerita-rakyat-detail">
                      {" "}
                      <button className="btn-kunjungi">
                        {" "}
                        <span>Lihat Detail</span>
                      </button>
                    </a>
                  </div>
                </div>
              </div>
              <div className="card-cerita">
                <img
                  className="header-card"
                  id="header-cerita"
                  src="assets/cerita2.jpg"
                ></img>
                <div className="content-card">
                  <div className="title-card">
                    Wayang, Warisan Budaya Jawa yang Mendunia
                  </div>
                  <div className="desc-card">
                    Wayang merupakan seni pertunjukan khas Jawa yang telah
                    diakui sebagai Warisan Budaya Tak Benda oleh UNESCO.
                  </div>
                </div>
                <div className="footer-card">
                  <div className="left-footer-card">
                    <div className="penerbit">Bintang Agustiano Effendy</div>
                    <div className="tanggal-terbit">11 Agustus 2007</div>
                  </div>
                  <div className="right-footer-card">
                    <a href="/cerita-rakyat-detail">
                      {" "}
                      <button className="btn-kunjungi">
                        {" "}
                        <span>Lihat Detail</span>
                      </button>
                    </a>
                  </div>
                </div>
              </div>
              <div className="card-cerita">
                <img
                  className="header-card"
                  id="header-cerita"
                  src="assets/cerita1.jpg"
                ></img>
                <div className="content-card">
                  <div className="title-card">
                    Wayang, Warisan Budaya Jawa yang Mendunia
                  </div>
                  <div className="desc-card">
                    Wayang merupakan seni pertunjukan khas Jawa yang telah
                    diakui sebagai Warisan Budaya Tak Benda oleh UNESCO.
                  </div>
                </div>
                <div className="footer-card">
                  <div className="left-footer-card">
                    <div className="penerbit">Bintang Agustiano Effendy</div>
                    <div className="tanggal-terbit">11 Agustus 2007</div>
                  </div>
                  <div className="right-footer-card">
                    <a href="/cerita-rakyat-detail">
                      {" "}
                      <button className="btn-kunjungi">
                        {" "}
                        <span>Lihat Detail</span>
                      </button>
                    </a>
                  </div>
                </div>
              </div>
              <div className="card-cerita">
                <img
                  className="header-card"
                  id="header-cerita"
                  src="assets/cerita3.jpg"
                ></img>
                <div className="content-card">
                  <div className="title-card">
                    Wayang, Warisan Budaya Jawa yang Mendunia
                  </div>
                  <div className="desc-card">
                    Wayang merupakan seni pertunjukan khas Jawa yang telah
                    diakui sebagai Warisan Budaya Tak Benda oleh UNESCO.
                  </div>
                </div>
                <div className="footer-card">
                  <div className="left-footer-card">
                    <div className="penerbit">Bintang Agustiano Effendy</div>
                    <div className="tanggal-terbit">11 Agustus 2007</div>
                  </div>
                  <div className="right-footer-card">
                    <a href="/cerita-rakyat-detail">
                      {" "}
                      <button className="btn-kunjungi">
                        {" "}
                        <span>Lihat Detail</span>
                      </button>
                    </a>
                  </div>
                </div>
              </div>
              <div className="card-cerita">
                <img
                  className="header-card"
                  id="header-cerita"
                  src="assets/cerita1.jpg"
                ></img>
                <div className="content-card">
                  <div className="title-card">
                    Wayang, Warisan Budaya Jawa yang Mendunia
                  </div>
                  <div className="desc-card">
                    Wayang merupakan seni pertunjukan khas Jawa yang telah
                    diakui sebagai Warisan Budaya Tak Benda oleh UNESCO.
                  </div>
                </div>
                <div className="footer-card">
                  <div className="left-footer-card">
                    <div className="penerbit">Bintang Agustiano Effendy</div>
                    <div className="tanggal-terbit">11 Agustus 2007</div>
                  </div>
                  <div className="right-footer-card">
                    <a href="/cerita-rakyat-detail">
                      {" "}
                      <button className="btn-kunjungi">
                        {" "}
                        <span>Lihat Detail</span>
                      </button>
                    </a>
                  </div>
                </div>
              </div>
              <div className="card-cerita">
                <img
                  className="header-card"
                  id="header-cerita"
                  src="assets/cerita2.jpg"
                ></img>
                <div className="content-card">
                  <div className="title-card">
                    Wayang, Warisan Budaya Jawa yang Mendunia
                  </div>
                  <div className="desc-card">
                    Wayang merupakan seni pertunjukan khas Jawa yang telah
                    diakui sebagai Warisan Budaya Tak Benda oleh UNESCO.
                  </div>
                </div>
                <div className="footer-card">
                  <div className="left-footer-card">
                    <div className="penerbit">Bintang Agustiano Effendy</div>
                    <div className="tanggal-terbit">11 Agustus 2007</div>
                  </div>
                  <div className="right-footer-card">
                    <a href="/cerita-rakyat-detail">
                      {" "}
                      <button className="btn-kunjungi">
                        {" "}
                        <span>Lihat Detail</span>
                      </button>
                    </a>
                  </div>
                </div>
              </div> */}
            </div>
            <div className="column-berita-terbaru" id="column-cerita-terbaru">
              <div className="title-berita-terbaru">Cerita terbaru</div>

              <div className="col-line">
                <div className="line"></div>
              </div>
              <div className="col-artikel-baru">
                {latestCerita.length === 0 ? (
                  <p>{error}</p>
                ) : (
                  latestCerita.map((data, index) => (
                    <a href={`/cerita-rakyat-detail/${data.id}`} key={index}>
                      <div className="card-berita-terbaru">
                        <div className="left-berita">
                          <img src={data.url_gambar} alt="" />
                        </div>
                        <div className="right-berita">
                          <div className="title-berita-baru">{data.judul}</div>
                          <div className="desc-berita-baru">
                            {data.deskripsi.length > 45
                              ? data.deskripsi.substring(0, 45) + "..."
                              : data.deskripsi}
                          </div>
                        </div>
                      </div>
                    </a>
                  ))
                )}
                {/* <a href="/cerita-rakyat-detail">
                  <div className="card-berita-terbaru">
                    <div className="left-berita">
                      <img src="assets/cerita1.jpg" alt="" />
                    </div>
                    <div className="right-berita">
                      <div className="title-berita-baru">
                        Legenda Batu Menangis: Kutukan Seorang Ibu
                      </div>
                      <div className="desc-berita-baru">
                        Legenda Batu Menangis adalah cerita rakyat dari
                        Kalimantan yang mengisahkan seorang gadis cantik tetapi
                        ....
                      </div>
                    </div>
                  </div>
                </a>
                <a href="/cerita-rakyat-detail">
                  <div className="card-berita-terbaru">
                    <div className="left-berita">
                      <img src="assets/cerita3.jpg" alt="" />
                    </div>
                    <div className="right-berita">
                      <div className="title-berita-baru">
                        Legenda Batu Menangis: Kutukan Seorang Ibu
                      </div>
                      <div className="desc-berita-baru">
                        Legenda Batu Menangis adalah cerita rakyat dari
                        Kalimantan yang mengisahkan seorang gadis cantik tetapi
                        ....
                      </div>
                    </div>
                  </div>
                </a>
                <a href="/cerita-rakyat-detail">
                  <div className="card-berita-terbaru">
                    <div className="left-berita">
                      <img src="assets/cerita2.jpg" alt="" />
                    </div>
                    <div className="right-berita">
                      <div className="title-berita-baru">
                        Legenda Batu Menangis: Kutukan Seorang Ibu
                      </div>
                      <div className="desc-berita-baru">
                        Legenda Batu Menangis adalah cerita rakyat dari
                        Kalimantan yang mengisahkan seorang gadis cantik tetapi
                        ....
                      </div>
                    </div>
                  </div>
                </a>
                <a href="/cerita-rakyat-detail">
                  <div className="card-berita-terbaru">
                    <div className="left-berita">
                      <img src="assets/cerita3.jpg" alt="" />
                    </div>
                    <div className="right-berita">
                      <div className="title-berita-baru">
                        Legenda Batu Menangis: Kutukan Seorang Ibu
                      </div>
                      <div className="desc-berita-baru">
                        Legenda Batu Menangis adalah cerita rakyat dari
                        Kalimantan yang mengisahkan seorang gadis cantik tetapi
                        ....
                      </div>
                    </div>
                  </div>
                </a>
                <a href="/cerita-rakyat-detail">
                  <div className="card-berita-terbaru">
                    <div className="left-berita">
                      <img src="assets/cerita2.jpg" alt="" />
                    </div>
                    <div className="right-berita">
                      <div className="title-berita-baru">
                        Legenda Batu Menangis: Kutukan Seorang Ibu
                      </div>
                      <div className="desc-berita-baru">
                        Legenda Batu Menangis adalah cerita rakyat dari
                        Kalimantan yang mengisahkan seorang gadis cantik tetapi
                        ....
                      </div>
                    </div>
                  </div>
                </a> */}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
export default CeritaRakyat;
