import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

const DetailTradisi = () => {
  const { id } = useParams();
  const [detailTradisi, setDetailTradisi] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          `${import.meta.env.VITE_BASE_URL_API}/tradisi/${id}`
        );
        if (response.status !== 200) {
          throw new Error("Tradisi tidak ditemukan");
        }
        console.log(response.data);
        setDetailTradisi(response.data.data);
      } catch (error) {
        setError(error);
      }
    };
    fetchData();
  }, [id]);

  return (
    <>
      <section id="detail-tradisi">
        <div className="content-detail-tradisi">
          <a href="/tradisi">
            <div
              className="col-kembali"
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                gap: "10px",
                cursor: "pointer",
              }}
            >
              <i class="bx bx-left-arrow-alt"></i> Kembali
            </div>
          </a>

          <div className="header-detail-tradisi">
            <div className="left-detail-tradisi">
              <img src={detailTradisi.url_gambar} alt="" />
            </div>
            <div className="right-detail-tradisi">
              <div className="title-detail-tradisi">{detailTradisi.judul}</div>
              <div className="desc-detail-tradisi">{detailTradisi.konten}</div>
              <div className="penulis-tradisi">-{detailTradisi.author}</div>
            </div>
          </div>
          <div className="footer-detail-tradisi">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d63282.3137862121!2d110.77783360671786!3d-7.559207068290307!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e7a16855db09efb%3A0xa6c2dbfdf275a4f9!2sKota%20S%2C%20Jawa%20Tengah!5e0!3m2!1sid!2sid!4v1741948518374!5m2!1sid!2sid"
              height="300"
              style={{ border: "0", width: "100%" }}
              allowfullscreen=""
              loading="lazy"
              referrerpolicy="no-referrer-when-downgrade"
            ></iframe>
          </div>
        </div>
      </section>
    </>
  );
};
export default DetailTradisi;
