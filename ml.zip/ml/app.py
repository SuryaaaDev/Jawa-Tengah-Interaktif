from flask import Flask, request, jsonify
from flask_cors import CORS
import http.client
import json

app = Flask(__name__)
CORS(app)

@app.route("/api/translate", methods=["POST"])
def translate():
    data = request.get_json()
    input_text = data.get("text", "")

    conn = http.client.HTTPSConnection("deep-translate1.p.rapidapi.com")

    headers = {
        'content-type': "application/json",
        'x-rapidapi-key': "9c0773ae8amsh60e729bcd9a477fp163f58jsn44bc821c8b1f",
        'x-rapidapi-host': "deep-translate1.p.rapidapi.com"
    }

    payload = json.dumps({
        "q": input_text,
        "source": "id",
        "target": "jv"
    })

    conn.request("POST", "/language/translate/v2", body=payload, headers=headers)
    res = conn.getresponse()
    data = res.read()
    response_json = json.loads(data.decode("utf-8"))

    translated_text = response_json["data"]["translations"]["translatedText"]
    return jsonify({"translatedText": translated_text})

if __name__ == "__main__":
    app.run(debug=True)
